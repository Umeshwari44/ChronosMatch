"""ChronosMatch: educational low-latency trading engine prototype.

Author: Umeshwari B
"""
__version__ = "0.1.0"
