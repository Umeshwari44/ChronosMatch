"""Minimal curses monitor (run in a real terminal; use WSL on Windows).

Read-only: it peeks at the buffer depth and never consumes events.
"""
import curses
import time

from .ring import MMapRing


def run(stdscr, path="chronosmatch.ipc"):
    curses.curs_set(0)
    ring = MMapRing(path, create=False)
    last_head, last_t, rate = 0, time.perf_counter(), 0.0
    try:
        while True:
            head, depth = ring._head(), len(ring)
            now = time.perf_counter()
            if now - last_t >= 0.5:
                rate = (head - last_head) / (now - last_t)
                last_head, last_t = head, now
            stdscr.erase()
            stdscr.addstr(0, 0, "ChronosMatch | ring buffer monitor")
            stdscr.addstr(2, 0, f"Events produced : {head:,}")
            stdscr.addstr(3, 0, f"Buffer depth    : {depth:,} / {ring.capacity:,}")
            stdscr.addstr(4, 0, f"Produce rate    : {rate:,.0f} orders/s")
            stdscr.addstr(6, 0, "Ctrl+C to exit")
            stdscr.refresh()
            time.sleep(0.05)
    finally:
        ring.close()


if __name__ == "__main__":
    curses.wrapper(run)
