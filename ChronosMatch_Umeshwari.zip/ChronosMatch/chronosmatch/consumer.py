"""Reads orders from the ring buffer and feeds the matcher; reports throughput."""
import time

from .ring import MMapRing
from .record import BUY

try:
    from .matching_engine import CythonMatcher as Matcher   # compiled extension
    ENGINE = "cython"
except ImportError:
    from .matcher_py import PyMatcher as Matcher            # pure-Python fallback
    ENGINE = "python"


def consume(path="chronosmatch.ipc", count=100_000):
    ring = MMapRing(path, create=False)
    matcher = Matcher()
    processed = trades = 0
    start = time.perf_counter_ns()
    try:
        while processed < count:
            order = ring.pop()
            if order is None:
                time.sleep(0)
                continue
            result = matcher.process(order.order_id, order.price_cents,
                                     order.quantity, order.side == BUY)
            trades += int(result[0])
            processed += 1
    finally:
        elapsed = (time.perf_counter_ns() - start) / 1e9
        ring.close()
    print(f"[{ENGINE}] consumed {processed:,}, trades={trades}, "
          f"{elapsed:.3f}s, {processed / elapsed:,.0f} orders/s")


if __name__ == "__main__":
    consume()
