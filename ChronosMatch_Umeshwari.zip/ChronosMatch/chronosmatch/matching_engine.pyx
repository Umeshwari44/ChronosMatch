# cython: language_level=3, boundscheck=False, wraparound=False, initializedcheck=False
# Compiled top-of-book matcher with C-typed state and a C struct for trade output.
cdef struct TradeRecord:
    long long price_cents
    int quantity
    long long buy_id
    long long sell_id

cdef class CythonMatcher:
    cdef long long best_bid
    cdef long long best_ask
    cdef long long bid_id
    cdef long long ask_id
    cdef int bid_qty
    cdef int ask_qty
    cdef bint has_bid
    cdef bint has_ask

    def __cinit__(self):
        self.has_bid = False
        self.has_ask = False
        self.best_bid = 0
        self.best_ask = 0
        self.bid_qty = 0
        self.ask_qty = 0
        self.bid_id = 0
        self.ask_id = 0

    cpdef tuple process(self, long long order_id, long long price_cents,
                        int quantity, bint is_buy):
        cdef TradeRecord trade
        cdef int filled
        if quantity <= 0:
            return (False, 0, 0, 0, 0)
        if is_buy:
            if self.has_ask and price_cents >= self.best_ask:
                filled = quantity if quantity < self.ask_qty else self.ask_qty
                trade.price_cents = self.best_ask
                trade.quantity = filled
                trade.buy_id = order_id
                trade.sell_id = self.ask_id
                self.ask_qty -= filled
                if self.ask_qty == 0:
                    self.has_ask = False
                return (True, trade.price_cents, trade.quantity,
                        trade.buy_id, trade.sell_id)
            self.best_bid, self.bid_id, self.bid_qty = price_cents, order_id, quantity
            self.has_bid = True
        else:
            if self.has_bid and price_cents <= self.best_bid:
                filled = quantity if quantity < self.bid_qty else self.bid_qty
                trade.price_cents = self.best_bid
                trade.quantity = filled
                trade.buy_id = self.bid_id
                trade.sell_id = order_id
                self.bid_qty -= filled
                if self.bid_qty == 0:
                    self.has_bid = False
                return (True, trade.price_cents, trade.quantity,
                        trade.buy_id, trade.sell_id)
            self.best_ask, self.ask_id, self.ask_qty = price_cents, order_id, quantity
            self.has_ask = True
        return (False, 0, 0, 0, 0)

    cpdef tuple top_of_book(self):
        return (self.best_bid if self.has_bid else None,
                self.best_ask if self.has_ask else None)
